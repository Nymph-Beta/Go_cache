#!/bin/bash
trap "rm server;kill 0" EXIT

go build -o server
./server -port=9528 &
./server -port=9527 &
./server -port=9529 &

sleep 2
echo ">>> start test"
# # 添加 POST
# curl -s -XPOST -H "Content-type: application/json" http://127.0.0.1:9528/ -d '{"key-27": "value 27"}' &
# curl -s -XPOST -H "Content-type: application/json" http://127.0.0.1:9528/ -d '{"key-28": "value 28"}' &
# curl -s -XPOST -H "Content-type: application/json" http://127.0.0.1:9527/ -d '{"key-29": "value 29"}' &
# curl -s http://127.0.0.1:9528/key-461 &
# curl -s http://127.0.0.1:9527/key-27 &
# curl -s -XDELETE http://127.0.0.1:9528/key-461 &

# curl -s -XPOST -H "Content-type: application/json" http://127.0.0.1:9527/_geecache/scores -d '{"myname": "电子科技大学@2023"}' &
# curl -s http://127.0.0.1:9528/_geecache/scores/myname &
# curl -s http://127.0.0.1:9528/_geecache/scores/Tom &

# curl -s -XPOST -H "Content-type: application/json" http://127.0.0.1:9527/_geecache/scores -d '{"tasks": ["task 1", "task 2", "task 3"]}' &
# curl -s http://127.0.0.1:9527/_geecache/scores/tasks &

# 删除 DELETE
# curl -s http://127.0.0.1:9527/Tom &
# curl -s -XDELETE http://127.0.0.1:9527/Jack &
# curl -s -XDELETE http://127.0.0.1:9527/Tom &
# curl -s http://127.0.0.1:9527/Tom &
# curl -s -XDELETE http://127.0.0.1:9527/Tom &


# curl -s http://127.0.0.1:9527/Tom &
# curl -s http://localhost:9527/123 &

# 访问9999端口 GET
# curl -s http://127.0.0.1:9999/Tom &
# curl -s http://localhost:9999/123 &
# curl -s http://localhost:9999/Jack &

wait