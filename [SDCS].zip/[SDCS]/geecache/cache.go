package geecache

import (
	"geecache/lru"
	"sync"
)

type cache struct {
	mu         sync.Mutex
	lru        *lru.Cache
	cacheBytes int64
}

// 封装的 lru.Add 方法
func (c *cache) add(key string, value ByteView) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.lru == nil {
		c.lru = lru.New(c.cacheBytes, nil)
	}
	c.lru.Add(key, value)
}

// 封装的 lru.Get 方法
func (c *cache) get(key string) (value ByteView, ok bool) {
	c.mu.Lock()
	defer c.mu.Unlock()		//上锁 解锁
	if c.lru == nil {	return	}

	if v, ok := c.lru.Get(key); ok {
		return v.(ByteView), ok
	}

	return
}

// 封装的 lru.Delete 方法
func (c *cache) delete(key string) (num int, ok bool) {
	c.mu.Lock()
	defer c.mu.Unlock()			//上锁 解锁
	if c.lru == nil {	return	}// 如果lru实例为nil，直接返回，不做后续查询  

	if num, ok := c.lru.Delete(key); ok {// 从lru缓存中查询键对应的值，断言v值的类型为ByteView后返回  
		return num, ok
	}

	// 如果删除失败，返回0和false  
	return
}
