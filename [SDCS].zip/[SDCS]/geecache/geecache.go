package geecache

import (
	"fmt"
	// "log"
	"sync"
)

// A Group is a cache namespace and associated data loaded spread over
type Group struct {
	name      string
	getter    Getter
	mainCache cache
	peers     PeerPicker
}

// A Getter loads data for a key.
type Getter interface {
	Get(key string) ([]byte, error)
}

// A GetterFunc implements Getter with a function.
type GetterFunc func(key string) ([]byte, error)

// Get implements Getter interface function
func (f GetterFunc) Get(key string) ([]byte, error) {
	return f(key)
}

var (
	mu     sync.RWMutex
	groups = make(map[string]*Group)
)

// NewGroup create a new instance of Group
func NewGroup(name string, cacheBytes int64, getter Getter) *Group {
	if getter == nil {
		panic("nil Getter")
	}
	mu.Lock()
	defer mu.Unlock()
	g := &Group{
		name:      name,
		getter:    getter,
		mainCache: cache{cacheBytes: cacheBytes},
	}
	groups[name] = g
	return g
}

// GetGroup returns the named group previously created with NewGroup, or
// nil if there's no such group.
func GetGroup(name string) *Group {
	mu.RLock()
	g := groups[name]
	mu.RUnlock()
	return g
}

// Add a key:value to cache
// Add 是Group结构体的一个方法，用于根据给定的 key-value 向缓存中添加数据。 
func (g *Group) Add(key string, value ByteView) (ByteView, error) {
	// key为空，直接返回
	if key == "" {	return ByteView{}, fmt.Errorf("key is required")	}
	// 是否加给自己
	if _, ok := g.peers.PickPeer(key); ok == 2{
		g.mainCache.add(key, value)
		// log.Println("[GeeCache] POST self")
		return ByteView{}, nil
	}
	// 如果不加自己，找该加到哪个节点上
	return g.loadAdd(key, value)
}

// Get value for a key from cache
// Get 是Group结构体的一个方法，用于根据给定的 key 从缓存中查找数据。 
func (g *Group) Get(key string) (ByteView, error) {
	// key为空，直接返回
	if key == "" {	return ByteView{}, fmt.Errorf("key is required")	}
	// 在mainCache中查找key
	if v, ok := g.mainCache.get(key); ok {
		// log.Println("[GeeCache] GET success")
		return v, nil
	}
	// 如果本端口没找到，从peer端口找
	return g.load(key)
}

// Delete value for a key from cache
// Delete 是Group结构体的一个方法，用于根据给定的 key 从缓存中删除数据。  
func (g *Group) Delete(key string) (int, error){
	// key为空，
	if key == "" {	return 0, fmt.Errorf("key is required")	}
	// 如果在mainCache中删除了key对应的值，返回找到的值和nil(无错误)。
	if num, ok := g.mainCache.delete(key); ok {    
		// log.Println("[GeeCache] DELETE success")
		return num, nil
	}
	// // 如果本端口没找到，从peer端口找，则返回load peer的delete
	return g.loadDel(key)
}

// RegisterPeers registers a PeerPicker for choosing remote peer
func (g *Group) RegisterPeers(peers PeerPicker) {
	if g.peers != nil {
		panic("RegisterPeerPicker called more than once")
	}
	g.peers = peers
}

// loadAdd函数 从peer上 添加/更新 数据
func (g *Group) loadAdd(key string, value ByteView) (val ByteView, err error) {
	if g.peers != nil {
		// 找该去的peer节点
		if peer, ok := g.peers.PickPeer(key); ok == 1 {
			// 去peer节点添加
			if val, err = g.addToPeer(peer, key, value); err == nil {
				return val, nil
			}
			// log.Println("[GeeCache] Failed to add to peer", err)
		}
	}

	return ByteView{}, err
}

// load函数 从peer上 找 数据
func (g *Group) load(key string) (value ByteView, err error) {
	if g.peers != nil {
		if peer, ok := g.peers.PickPeer(key); ok == 1 {
			if value, err = g.getFromPeer(peer, key); err == nil {
				return value, nil
			}
			// log.Println("[GeeCache] Failed to get from peer", err)
		}
	}
	// log.Println("[GeeCache] GET Failed (has been deleted)")
	return ByteView{}, fmt.Errorf("%s not exist", key)
}

// loadDel函数 从peer上 找+删除 数据
func (g *Group) loadDel(key string) (num int, err error) {
	if g.peers != nil {
		if peer, ok := g.peers.PickPeer(key); ok == 1 {
			if num, ok := g.delFromPeer(peer, key); ok {
				return num, nil
			}
			// log.Println("[GeeCache] Failed to delete from peer," , err)
		}
	}
	// log.Println("[GeeCache] DELETE Failed, (has been deleted / not exist)")
	return 0, err
}

// 向peer添加/更新
func (g *Group) addToPeer(peer PeerGetter, key string, value ByteView) (ByteView, error) {
	bytes, err := peer.Add(g.name, key, value)
	if err != nil {	return ByteView{}, err	}
	return ByteView{b: bytes}, nil
}

// 从peer获取
func (g *Group) getFromPeer(peer PeerGetter, key string) (ByteView, error) {
	bytes, err := peer.Get(g.name, key)
	if err != nil {	return ByteView{}, err	}
	return ByteView{b: bytes}, nil
}

// 从peer删除
func (g *Group) delFromPeer(peer PeerGetter, key string) (int, bool) {
	num, err:= peer.Delete(g.name, key)
	if err !=nil {	return 0, false		}
	return num, true
}
