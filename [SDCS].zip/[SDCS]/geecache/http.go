package geecache

import (
	"encoding/json"
	"fmt"
	"geecache/consistenthash"
	"strconv"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync"
)

const (
	defaultBasePath = "/_geecache/"
	defaultReplicas = 50
)

// HTTPPool implements PeerPicker for a pool of HTTP peers.
type HTTPPool struct {
	// this peer's base URL, e.g. "https://example.net:8000"
	self        string
	basePath    string
	mu          sync.Mutex // guards peers and httpGetters
	peers       *consistenthash.Map
	httpGetters map[string]*httpGetter // keyed by e.g. "http://10.0.0.2:8008"
}

// NewHTTPPool initializes an HTTP pool of peers.
func NewHTTPPool(self string) *HTTPPool {
	return &HTTPPool{
		self:     self,
		basePath: defaultBasePath,
	}
}

// Log info with server name
func (p *HTTPPool) Log(format string, v ...interface{}) {
	log.Printf("[Server %s] %s", p.self, fmt.Sprintf(format, v...))
}

// ServeHTTP handle all http requests
func (p *HTTPPool) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if !strings.HasPrefix(r.URL.Path, p.basePath) {
		// panic("HTTPPool serving unexpected path: " + r.URL.Path)
		r.URL.Path = strings.Replace(r.URL.Path, "/", "/_geecache/scores/", -1)
	}
	// p.Log("%s %s", r.Method, r.URL.Path)
	// /<basepath>/<groupname>/<key> required
	parts := strings.SplitN(r.URL.Path[len(p.basePath):], "/", 2)
	groupName := parts[0]
	// key := parts[1]
	group := GetGroup(groupName)
	if group == nil {
		http.Error(w, "no such group: "+groupName, http.StatusNotFound)
		return
	}

	if r.Method == "POST" {
		// log.Println(r.Body) // http请求的主体内容
		body0, err := ioutil.ReadAll(r.Body) // 以切片的形式全部获取
		p.Log("%s %s", r.Method, body0)      // 打印HTTP请求的方法和json内容
		if err != nil {
			http.Error(w, "读取 request body 失败", http.StatusInternalServerError)
			return
		}
		var data map[string]interface{}    // 把json解码到map[]里
		err = json.Unmarshal(body0, &data) // body中的json解码为key和value存入map
		if err != nil {
			http.Error(w, "转换 JSON 失败", http.StatusBadRequest)
			return
		}
		// fmt.Println(data)
		for key, value := range data {
			var bv ByteView
			if strValue, ok := value.(string); ok {
				bytes := []byte(strValue)
				bv = ByteView{b: bytes}
			} else {
				// 如果不是字符串，强行转换为字符串
				strValue := fmt.Sprintf("%v", value)
				bytes := []byte(strValue)
				bv = ByteView{b: bytes}
			}
			// populateCache 是Group结构体的一个方法，用于将数据填充到缓存中。
			// log.Println("[HTTP-post] key-value", key, bv.String())
			_, err := group.Add(key, bv)
			if err != nil {
				http.Error(w, "添加过程失败", http.StatusInternalServerError)
				return
			}
		}

	} else if r.Method == "GET" {
		// 打印HTTP请求的方法和路径
		p.Log("%s %s", r.Method, r.URL.Path)
		key := parts[1] // 提取key
		// 通过key从组中获取信息，view保存Get函数返回的信息。从peer回来应是这样{"Tom":"630"}
		view, err := group.Get(key)
		if err != nil {
			http.Error(w, err.Error(), http.StatusNotFound)
			return
		}
		// ==================================================================
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		// 把查到的数据编码成json然后传给http的回复
		k := string([]byte(key))
		v := string(view.ByteSlice())
		data := make(map[string]string)
		data[k] = v
		jsonData, err := json.Marshal(data)
		if err != nil {
			fmt.Println("转换为JSON时发生错误:", err)
			return
		}
		// // 一些输出方便判断
		// fmt.Println("k:", k);	fmt.Println("v", v)
		// jsonString := string(jsonData)	// 转换为字符串
		// fmt.Println("jsonString:", jsonString)	// 输出形如 {"Tom":"630"}
		if strings.HasPrefix(v, "{") {
			w.Write([]byte(v))
		} else {
			w.Write(jsonData) //这样格式正确
		}
		// ==================================================================

	} else if r.Method == "DELETE" {
		p.Log("%s %s", r.Method, r.URL.Path)
		key := parts[1]
		// 通过key从组中获取信息，如果获取信息时发生错误，返回错误信息
		num, err := group.Delete(key)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		numstr := fmt.Sprint(num)
		// fmt.Println(num)
		w.Write([]byte(numstr))

	} else { // 其他方法不识别不操作
		p.Log("%s %s", r.Method, r.URL.Path)
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
	}

}

// Set updates the pool's list of peers.
// 节点动态更新，把这些节点Set进
func (p *HTTPPool) Set(peers ...string) {
	p.mu.Lock()
	defer p.mu.Unlock() // 锁
	p.peers = consistenthash.New(defaultReplicas, nil)
	p.peers.Add(peers...)
	p.httpGetters = make(map[string]*httpGetter, len(peers))
	for _, peer := range peers {
		p.httpGetters[peer] = &httpGetter{baseURL: peer + p.basePath}
	}
}

// PickPeer picks a peer according to key
// 根据key，选择Peer节点，用的是一致性哈希
func (p *HTTPPool) PickPeer(key string) (PeerGetter, int) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if peer := p.peers.Get(key); peer != "" && peer != p.self {
		log.Println("Pick peer ", peer)
		return p.httpGetters[peer], 1
	}else if peer == p.self {	// 如果就是他自己
		// log.Println("Pick peer self")
		return nil, 2
	}
	return nil, 0
}

var _ PeerPicker = (*HTTPPool)(nil)

// 实例化的peers.go
type httpGetter struct {
	baseURL string
}

// peer.Add 对Peers发起POST请求
func (h *httpGetter) Add(group string, key string, value ByteView) ([]byte, error) {
	u := fmt.Sprintf(
		"%v%v/%v",
		h.baseURL,
		url.QueryEscape(group),
		url.QueryEscape(key),
	)

	// 把要添加的 k-v 数据编码成json 和reader，然后传给http请求
	k := string([]byte(key))
	v := string(value.ByteSlice())
	data := make(map[string]string)
	data[k] = v
	jsonData, _ := json.Marshal(data)
	// log.Println("[peer-Add] jsonData:" , string(jsonData))
	reader := strings.NewReader(string(jsonData))
	// 发送post请求
	resp, err := http.Post(u, "application/json", reader)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("server returned: %v", resp.Status)
	}
	// 读取所有的响应内容。其实这个在这里是没用的，不需要返回值也行
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("reading response body: %v", err)
	}
	return body, err
}

// peer.Get	对peers发起GET请求
func (h *httpGetter) Get(group string, key string) ([]byte, error) {
	u := fmt.Sprintf(
		"%v%v/%v",
		h.baseURL,
		url.QueryEscape(group),
		url.QueryEscape(key),
	)
	// 发送get请求
	res, err := http.Get(u)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("server returned: %v", res.Status)
	}
	// 检查get到的body
	bytes, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return nil, fmt.Errorf("reading response body: %v", err)
	}

	return bytes, nil
}

// peer.Delete 对Peers发起DELETE请求
func (h *httpGetter) Delete(group string, key string) (int, error) {
	u := fmt.Sprintf(
		"%v%v/%v",
		h.baseURL,
		url.QueryEscape(group),
		url.QueryEscape(key),
	)

	client := &http.Client{}
	// 创建delete请求
	req, err := http.NewRequest("DELETE", u, nil)
	if err != nil {
		return 0, err
	}
	// 发送delete请求
	res, err := client.Do(req)
	if err != nil {
		return 0, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return 0, fmt.Errorf("server returned: %v", res.Status)
	}
	// 检查delete回复的body
	numbyte, err := ioutil.ReadAll(res.Body)
	str := string(numbyte) // 将[]byte转换为string
	num, err := strconv.Atoi(str) // 将string转换为int
	// log.Println("[PeerDEL] DEL NUM：" , num)
	if err != nil {
		return 0, fmt.Errorf("reading response body: %v", err)
	}
	return num, nil
}

var _ PeerGetter = (*httpGetter)(nil)
