package geecache

// PeerPicker is the interface that must be implemented to locate
// the peer that owns a specific key.
type PeerPicker interface {
	// PickPeer用来hash寻找节点，ok=1找到节点，ok=2节点就是自己
	PickPeer(key string) (peer PeerGetter, ok int)
}

// PeerGetter is the interface that must be implemented by a peer.
type PeerGetter interface {
	// Add函数用来给peer发送POST请求，返回值不必要
	Add(group string, key string, value ByteView)	([]byte, error)
	// Get函数用来给peer发送GET请求，返回找到的value值
	Get(group string, key string)	([]byte, error)
	// Delete函数用来给peer发送DELETE请求，返回删除的数量
	Delete(group string, key string)	(int, error)
}
