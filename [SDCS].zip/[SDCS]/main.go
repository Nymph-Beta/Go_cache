package main

import (
	"flag"
	"fmt"
	"geecache"
	"log"
	"net/http"
)

func createGroup() *geecache.Group {
	return geecache.NewGroup("scores", 20480, geecache.GetterFunc(
		func(key string) ([]byte, error) {
			return nil, fmt.Errorf("%s not exist", key)
		}))
}

func startCacheServer(addr string, addrs []string, gee *geecache.Group) {
	peers := geecache.NewHTTPPool(addr)
	// 节点更新，作为一个节点添加进hash的环
	peers.Set(addrs...)
	gee.RegisterPeers(peers)
	log.Println("geecache is running at", addr)
	log.Fatal(http.ListenAndServe(addr[7:], peers))
}


func main() {
	var port int
	flag.IntVar(&port, "port", 9527, "Geecache server port")
	flag.Parse()

	addrMap := map[int]string{
		9527: "http://localhost:9527",
		9528: "http://localhost:9528",
		9529: "http://localhost:9529",
	}
	// 把map中的url地址加入到一个数组中
	var addrs []string
	for _, v := range addrMap {
		addrs = append(addrs, v)
	}

	gee := createGroup()
	
	startCacheServer(addrMap[port], addrs, gee)
}
